# Cat-ch 🐾

**捕捉猫咪，也收藏心动。** Cat-ch 是一个分享小猫照片的安卓应用：看看别人遇见的小猫，也把你拍到的可爱瞬间分享出来。

## 下载安装

1. 打开 [下载页面](https://github.com/adrian147258/Cat-ch/releases/tag/v0.6.0-beta)。
2. 在 **Assets** 中下载 `Cat-ch-0.6.apk`。
3. 在 Android 手机中打开安装包，按系统提示安装。需要 Android 8.0 或更新版本。

这是测试版，尚未完成所有真机测试。如果手机提示安装来源权限，请根据设备的系统提示选择是否允许安装。

## 怎么使用

1. 打开 App，用邮箱注册并完成验证码验证；之后可使用邮箱和密码或邮箱验证码登录。
2. 在 **广场** 浏览其他人发布的小猫，喜欢的内容可以点赞或收藏。
3. 点击底部 **＋** 选择图片、写下文字并发布；发布后，其他使用者可以看到。
4. 在 **我的** 查看发布、点赞和收藏；可以编辑个性签名，点 **＋** 更换猫猫窝封面。封面按原比例完整显示。

发帖、登录与浏览社区需要联网和可用的后台服务。当前封面和个性签名保存在本机；成就等级制度尚未加入。

## 开发与实现

客户端使用 Android 原生 Java 开发。登录和社区数据由后端服务提供。本仓库包含 Android 客户端及 backend 目录中的后端源码。仓库中的服务地址使用占位配置，下载的测试版安装包则连接现有服务。

使用 Android Studio 打开项目，安装 JDK 17 和 Android SDK 35。构建前在未提交的 `local.properties` 中配置自己的服务地址：

```properties
catch.apiBaseUrl=https://your-api.example.com
```

调试签名由开发环境生成；不要上传自己的签名文件、密码、API 密钥、会话令牌或生产配置。

## 许可证

源码以 [MIT License](LICENSE) 发布。

## 0.6 更新

- 新增抽卡导航与已获得卡片收藏。
- 每日一包、每包一张，北京时间零点刷新，服务端限制重复抽取。
- 绿卡 70%、蓝卡 20%、紫卡 8%、金卡 2%；共 43 张卡。
- 手机滑动撕包、转动手机改变卡片光效，稀有度越高揭晓动画越长。
- 新增评论与回复。

## 后端配置

配置 DB (D1)、PICTURES (R2)、AUTH_BASE_URL、BREVO_SENDER_EMAIL，以及私密 BETTER_AUTH_SECRET、BREVO_API_KEY。现有数据库新增功能需运行 backend/cards-migration.sql 和 backend/comments-migration.sql；不要重置已有数据。后端鉴权使用 better-auth，构建时需按目标运行环境配置 Node 兼容。

字体授权参见 app/src/main/assets/LXGWWenKai-OFL.txt。
